import java.awt.Color;

import javax.swing.JFrame;
//DONE!!!
public class Breakout extends JFrame{
	
	static final long serialVersionUID = 1L;
	
	private BreakoutPanel panel;
 
	public Breakout() {
		// TODO: Set the size of the screen (use Settings.WINDOW_WIDTH/HEIGHT)
		// TODO: Set the title
		// TODO: Set the background colour to white
		// TODO: Set resizable to false
		
		setSize(Settings.WINDOW_WIDTH, Settings.WINDOW_HEIGHT);
		setBackground(Color.BLUE);
		setTitle("Breakout Game");
		setResizable(false);
		setVisible(true);
		
		//adding bricks class to the frame
		
		
		
		
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel = new BreakoutPanel(this);
        add(panel);
		// TODO: Set visible to true
        setVisible(true);
	}

	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
	         public void run() {
	        	 new Breakout();	
	         }
		});

	}
}
